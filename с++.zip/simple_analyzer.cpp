#include <iostream>
#include <fstream>
#include <string>

// Простая структура для хранения результатов анализа
struct AnalysisResult {
    int totalLines = 0;
    int codeLines = 0;
    int commentLines = 0;
    int blankLines = 0;
};

// Функция для анализа одного файла
AnalysisResult analyzeFile(const std::string& filename) {
    AnalysisResult result;
    std::ifstream file(filename);
    std::string line;
    
    // Проверяем, открылся ли файл
    if (!file.is_open()) {
        std::cout << "Ошибка: Не удалось открыть файл " << filename << std::endl;
        return result;
    }
    
    // Читаем файл построчно
    while (std::getline(file, line)) {
        result.totalLines++;
        
        // Проверяем пустую строку
        if (line.empty() || line.find_first_not_of(" \t") == std::string::npos) {
            result.blankLines++;
            continue;
        }
        
        // Проверяем комментарий
        if (line.find("//") != std::string::npos) {
            result.commentLines++;
            continue;
        }
        
        // Если строка не пустая и не комментарий, считаем её кодом
        result.codeLines++;
    }
    
    file.close();
    return result;
}

int main() {
    std::string filename1, filename2;
    
    // Запрашиваем имена файлов у пользователя
    std::cout << "Введите имя первого файла: ";
    std::cin >> filename1;
    
    std::cout << "Введите имя второго файла (или 'нет' если не нужно): ";
    std::cin >> filename2;
    
    // Анализируем первый файл
    std::cout << "\nАнализ файла: " << filename1 << std::endl;
    std::cout << "----------------------------------------" << std::endl;
    AnalysisResult result1 = analyzeFile(filename1);
    
    std::cout << "Всего строк: " << result1.totalLines << std::endl;
    std::cout << "Строк кода: " << result1.codeLines << std::endl;
    std::cout << "Строк комментариев: " << result1.commentLines << std::endl;
    std::cout << "Пустых строк: " << result1.blankLines << std::endl;
    
    // Анализируем второй файл, если он указан
    if (filename2 != "нет") {
        std::cout << "\nАнализ файла: " << filename2 << std::endl;
        std::cout << "----------------------------------------" << std::endl;
        AnalysisResult result2 = analyzeFile(filename2);
        
        std::cout << "Всего строк: " << result2.totalLines << std::endl;
        std::cout << "Строк кода: " << result2.codeLines << std::endl;
        std::cout << "Строк комментариев: " << result2.commentLines << std::endl;
        std::cout << "Пустых строк: " << result2.blankLines << std::endl;
    }
    
    return 0;
} 