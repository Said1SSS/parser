#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <regex>
#include <map>

class CodeAnalyzer {
private:
    struct FileMetrics {
        int totalLines;
        int codeLines;
        int commentLines;
        int blankLines;
        int functionCount;
        std::map<std::string, int> variableDeclarations;
    };

    FileMetrics analyzeFile(const std::string& filename) {
        FileMetrics metrics = {0, 0, 0, 0, 0, {}};
        std::ifstream file(filename);
        std::string line;
        
        std::regex functionPattern(R"(\w+\s+\w+\s*\([^)]*\)\s*\{)");
        std::regex variablePattern(R"(\w+\s+(\w+)\s*=?\s*[^;]*;)");
        std::regex commentPattern(R"(//.*|/\*.*\*/)");
        
        bool inMultiLineComment = false;
        
        while (std::getline(file, line)) {
            metrics.totalLines++;
            
            // Skip empty lines
            if (line.empty() || std::all_of(line.begin(), line.end(), isspace)) {
                metrics.blankLines++;
                continue;
            }
            
            // Check for multi-line comments
            if (line.find("/*") != std::string::npos) {
                inMultiLineComment = true;
                metrics.commentLines++;
                continue;
            }
            if (line.find("*/") != std::string::npos) {
                inMultiLineComment = false;
                metrics.commentLines++;
                continue;
            }
            if (inMultiLineComment) {
                metrics.commentLines++;
                continue;
            }
            
            // Check for single-line comments
            if (std::regex_search(line, commentPattern)) {
                metrics.commentLines++;
                continue;
            }
            
            // Count functions
            if (std::regex_search(line, functionPattern)) {
                metrics.functionCount++;
            }
            
            // Count variable declarations
            std::smatch varMatch;
            if (std::regex_search(line, varMatch, variablePattern)) {
                metrics.variableDeclarations[varMatch[1]]++;
            }
            
            metrics.codeLines++;
        }
        
        return metrics;
    }

public:
    void analyzeFiles(const std::vector<std::string>& filenames) {
        for (const auto& filename : filenames) {
            std::cout << "\nAnalyzing file: " << filename << "\n";
            std::cout << "----------------------------------------\n";
            
            try {
                FileMetrics metrics = analyzeFile(filename);
                
                std::cout << "Total lines: " << metrics.totalLines << "\n";
                std::cout << "Code lines: " << metrics.codeLines << "\n";
                std::cout << "Comment lines: " << metrics.commentLines << "\n";
                std::cout << "Blank lines: " << metrics.blankLines << "\n";
                std::cout << "Function count: " << metrics.functionCount << "\n";
                
                std::cout << "\nVariable declarations:\n";
                for (const auto& [var, count] : metrics.variableDeclarations) {
                    std::cout << "  " << var << ": " << count << " times\n";
                }
            }
            catch (const std::exception& e) {
                std::cerr << "Error analyzing file: " << e.what() << "\n";
            }
        }
    }
};

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cout << "Usage: " << argv[0] << " <file1> [file2]\n";
        return 1;
    }
    
    std::vector<std::string> filenames;
    for (int i = 1; i < argc; i++) {
        filenames.push_back(argv[i]);
    }
    
    CodeAnalyzer analyzer;
    analyzer.analyzeFiles(filenames);
    
    return 0;
} 