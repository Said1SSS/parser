# C++ Code Analyzer

A simple C++ code analyzer that can analyze 1-2 C++ source files and provide basic metrics about the code.

## Features

- Counts total lines, code lines, comment lines, and blank lines
- Detects function declarations
- Counts variable declarations
- Supports both single-line and multi-line comments
- Can analyze multiple files in one run

## Building the Project

### Using CMake

```bash
mkdir build
cd build
cmake ..
cmake --build .
```

### Using g++ directly

```bash
g++ -std=c++17 code_analyzer.cpp -o code_analyzer
```

## Usage

```bash
./code_analyzer <file1> [file2]
```

Example:
```bash
./code_analyzer main.cpp utils.cpp
```

## Output

The analyzer will show:
- Total number of lines
- Number of code lines
- Number of comment lines
- Number of blank lines
- Number of functions
- List of variable declarations and their count 